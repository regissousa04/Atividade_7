package br.edu.ifgoias.sistemaacademico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
