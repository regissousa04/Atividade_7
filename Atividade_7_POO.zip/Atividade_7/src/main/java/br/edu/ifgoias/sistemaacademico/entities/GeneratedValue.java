package br.edu.ifgoias.sistemaacademico.entities;

public @interface GeneratedValue {

}
